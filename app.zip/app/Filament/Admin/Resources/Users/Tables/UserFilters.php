<?php

declare(strict_types=1);

namespace App\Filament\Admin\Resources\Users\Tables;

class UserFilters
{
    /**
     * @var array
     */
    protected static $filters = [];

    public static function make(): array
    {
        return self::getFilters();
    }

    private static function getDefaultFilters(): array
    {
        return [
            Filters\Verified::make(),
            Filters\Languages::make(),
            Filters\Countries::make(),
            Filters\Roles::make(),
        ];
    }

    private static function getFilters(): array
    {
        return array_merge(self::getDefaultFilters(), self::$filters);
    }

    public static function register(\Filament\Tables\Filters\BaseFilter | array $action): void
    {
        if (is_array($action)) {
            foreach ($action as $item) {
                if (! $item instanceof \Filament\Tables\Filters\BaseFilter) {
                    continue;
                }

                self::$filters[] = $item;
            }

            return;
        }

        self::$filters[] = $action;
    }
}
