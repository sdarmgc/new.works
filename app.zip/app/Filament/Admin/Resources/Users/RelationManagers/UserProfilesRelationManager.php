<?php

namespace App\Filament\Admin\Resources\Users\RelationManagers;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\CreateAction;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Checkbox;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
// use Filament\Tables\Columns\Select;
use Filament\Tables\Table;

class UserProfilesRelationManager extends RelationManager
{
    protected static string $relationship = 'profile';

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Checkbox::make('gender')->required()->label(trans('Brother(or Sister)')),
                TextInput::make('first_name')->required()->maxLength(255)->label(trans('First Name')),
                TextInput::make('last_name')->required()->maxLength(255)->label(trans('Last Name')),
                TextInput::make('phone')->maxLength(255)->label(trans('phone')),
                TextInput::make('phone_app')->maxLength(255)->label(trans('phone_app')),
                TextArea::make('extra')->maxLength(1023)->label(trans('extra')),
                Select::make('notfy')->required()->options([
                    '0' => 'None',
                    '1' => 'Email',
                    '2' => 'SMS'
                ])->label(trans('notfy')),
                Checkbox::make('active')->required()->label(trans('active')),
                TextInput::make('last_login_at')->readOnly()->label(trans('last_login_at')),
                TextInput::make('last_login_ip')->readOnly()->label(trans('last_login_ip')),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('first_name')
            ->columns([
                ToggleColumn::make('gender')->sortable()->label(trans('Brother(or Sister)')),
                TextColumn::make('first_name')->sortable()->searchable()->label(trans('First Name')),
                TextColumn::make('last_name')->sortable()->searchable()->label(trans('Last Name')),
                TextColumn::make('phone')->sortable()->searchable()->label(trans('phone')),
                TextColumn::make('phone_app')->sortable()->searchable()->label(trans('phone_app')),
                TextColumn::make('extra')->label(trans('extra')),
                TextColumn::make('notfy')->label(trans('notfy')),
                ToggleColumn::make('active')->label(trans('active')),
                TextColumn::make('last_login_at')->label(trans('last_login_at')),
                TextColumn::make('last_login_ip')->label(trans('last_login_ip')),
            ])
            ->filters([
                //
            ])
            ->headerActions([
                // CreateAction::make(),
            ])
            ->recordActions([
                EditAction::make(),
                // DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    // DeleteBulkAction::make(),
                ]),
            ]);
    }
}
